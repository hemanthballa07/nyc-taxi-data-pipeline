---
name: brainstorm
description: Think through a design decision, tradeoff, or problem before implementing. Use when the user says "brainstorm", "think through", "what's the best way to", "how should I", or when facing a non-obvious architectural or data modeling choice.
---

# Brainstorm Skill

When brainstorming, follow this structure:

## 1. Restate the Problem
Summarize what we're trying to solve in one sentence. If it's vague, ask one clarifying question before proceeding.

## 2. List Options (at least 2-3)
For each option:
- **What**: describe the approach concisely
- **Pros**: what makes it attractive
- **Cons**: what are the risks or downsides
- **Effort**: rough time estimate (hours, not days)

## 3. Recommend One
Pick the best option for THIS project's context:
- We're a student portfolio project, not a Fortune 500 company
- Simplicity wins over sophistication
- "Good enough and done" beats "perfect and unfinished"
- Prefer approaches that teach transferable skills (SQL, Python, Docker patterns that work at any company)

## 4. Identify What Could Go Wrong
List 1-2 things that might bite us later with the recommended approach, and how to mitigate them.

## Topics This Skill Is Good For
- Data modeling choices (star schema design, grain decisions, SCD types)
- Tool selection (which Python library, which approach to loading)
- Pipeline design (batch vs micro-batch, full refresh vs incremental)
- Testing strategy (what to test, what's overkill)
- Performance tradeoffs (indexing, partitioning, materialization)
- "Should I add X to this project?" (scope management)

## Anti-Patterns to Avoid When Brainstorming
- Don't over-engineer: if the answer is obvious, just say so and move on
- Don't recommend tools the user hasn't learned yet without flagging the learning curve
- Don't suggest cloud services when the project runs locally on Docker
- Don't write code during brainstorming — this is thinking time, not building time
- Don't produce a 2000-word essay when a 200-word answer covers it
