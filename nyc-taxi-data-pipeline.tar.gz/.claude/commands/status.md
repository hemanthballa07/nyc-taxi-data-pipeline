---
name: status
description: Check the current state of the project — what's built, what's running, what's left.
disable-model-invocation: true
---

Check the project status by:

1. Run `docker compose ps` to see which services are running
2. Check if `data/raw/` has any Parquet files downloaded
3. Connect to Postgres and check if `raw.yellow_taxi_trips` exists and has data:
   ```sql
   SELECT count(*) FROM raw.yellow_taxi_trips;
   SELECT min(tpep_pickup_datetime), max(tpep_pickup_datetime) FROM raw.yellow_taxi_trips;
   ```
4. Check if dbt models exist in `dbt/models/` and if they've been run:
   ```bash
   ls dbt/models/staging/ dbt/models/marts/ 2>/dev/null
   ls dbt/target/manifest.json 2>/dev/null
   ```
5. Check what Airflow DAGs exist in `dags/`
6. Summarize: what phases are complete, what's the next task to work on

Report findings in a concise table format.
