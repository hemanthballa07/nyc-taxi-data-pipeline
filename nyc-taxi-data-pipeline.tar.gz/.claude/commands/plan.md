---
name: plan
description: Create an implementation plan before writing code. Use before starting any new feature.
disable-model-invocation: true
---

Before writing any code for: $ARGUMENTS

1. Read the relevant skill files in `.claude/skills/` to understand conventions
2. Check existing code to avoid duplication
3. Write a plan as a numbered checklist in `docs/plans/` with:
   - What files will be created or modified
   - What the expected inputs/outputs are
   - What tests need to be written
   - Any dependencies or prerequisites
4. Present the plan and wait for approval before implementing
